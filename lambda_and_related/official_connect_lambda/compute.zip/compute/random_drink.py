import json,random

def random_drink():
    drinks = ["coffee","tea","pepsi"]
    return random.choice(drinks)
def lambda_handler(event, context):
    drink = random_drink()
    m = f"u should drink some {drink}"

    return {
        'statusCode':200,
        'body':json.dumps({"message":m,'drink':drink})
    }